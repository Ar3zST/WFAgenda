﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace WFGravarDados
{
    public partial class Form1 : Form
    {
        private MySqlConnection Conexao;
        private string data_source = "datasource=localhost;username=root;" +
                    "database=db_agenda;password=12345";
        private int? id_Contato_Sel = null;

        // INICIALIZAÃ‡ÃƒO
        public Form1()
        {
            InitializeComponent();

            lstContatos.View = View.Details; // Detalhamento da estrutura do listview
            lstContatos.AllowColumnReorder = true; // Permite alterar o tamanho da coluna 
            lstContatos.FullRowSelect = true; // Permite selecionar uma linha  
            lstContatos.GridLines = true; // Cria linhas de grade

            // DefiniÃ§Ã£o das colunas no ListView (Nome da coluna, tamanho e alinhamento)
            lstContatos.Columns.Add("ID", 30, HorizontalAlignment.Left);
            lstContatos.Columns.Add("NOME", 150, HorizontalAlignment.Left);
            lstContatos.Columns.Add("E-MAIL", 150, HorizontalAlignment.Left);
            lstContatos.Columns.Add("TELEFONE", 30, HorizontalAlignment.Left);

            carregarContatos();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        // CARREGAR DADOS DO BD DB_AGENDA NA LISTVIEW
        private void carregarContatos()
        {
            try
            {
                // Criar conexÃ£o
                Conexao = new MySqlConnection(data_source);
                string sql = "SELECT * " +
                             "FROM contatos ORDER BY id DESC";
                MySqlCommand comando = new MySqlCommand(sql, Conexao);
                Conexao.Open();
                MySqlDataReader reader = comando.ExecuteReader();
                lstContatos.Items.Clear();
                while (reader.Read())
                {
                    string[] linha =
                    {
                        reader.GetString(0),
                        reader.GetString(1),
                        reader.GetString(2),
                        reader.GetString(3),
                    };
                    var linha_listview = new ListViewItem(linha);
                    lstContatos.Items.Add(linha_listview);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        // EVENTO DO BOTÃƒO ENVIAR
        private void btnEnviar_Click(object sender, EventArgs e)
        {

            try
            {
                // Criar conexÃ£o
                Conexao = new MySqlConnection(data_source);
                Conexao.Open();
                MySqlCommand cmd = new MySqlCommand();

                cmd.Connection = Conexao;

                // Verifica se a aoperaÃ§Ã£o Ã© uma inserÃ§Ã£o ou atualizaÃ§Ã£o
                if (id_Contato_Sel == null)
                {
                    // Comandos SQL para INSERT

                    cmd.CommandText = "INSERT INTO contatos (nome, email, telefone) " +
                                      "VALUES " +
                                      "(@nome, @email, @telefone)";

                    cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@telefone", mtxtTelefone.Text);

                    cmd.ExecuteNonQuery();

                    // Mensagem de conclusÃ£o da operaÃ§Ã£o
                    MessageBox.Show("Contato inserido com Sucesso! ", " ",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);

                    limparCampos();

                    carregarContatos();
                }
                else
                {
                    // Comandos SQL para UPDATE

                    cmd.CommandText = "UPDATE contatos SET " +
                                      "nome=@nome, email=@email,telefone=@telefone " +
                                      "WHERE id=@id";

                    //cmd.Prepare();

                    cmd.Parameters.AddWithValue("@id", id_Contato_Sel);
                    cmd.Parameters.AddWithValue("@nome", txtNome.Text);
                    cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@telefone", mtxtTelefone.Text);

                    cmd.ExecuteNonQuery();

                    // Mensagem de conclusÃ£o da operaÃ§Ã£o
                    MessageBox.Show("Contato Atualizado com Sucesso! ", " ",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information);

                    limparCampos();

                    btnExcluir.Visible = false;

                    carregarContatos();
                }
            }

            catch (MySqlException ex)
            {
                MessageBox.Show("Erro " + ex.Number + " Ocorreu: " + ex.Message,
                                "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();
            }
        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        // EVENTO BOTÃƒO BUSCAR CONTATO
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "'%" + txtBuscar.Text + "%'";
                // Criar conexÃ£o
                Conexao = new MySqlConnection(data_source);
                string sql = "SELECT * " +
                             "FROM contatos WHERE nome  " +
                             "LIKE " + q + "OR email LIKE " + q;
                // Executar comando de busca
                MySqlCommand comando = new MySqlCommand(sql, Conexao);
                Conexao.Open();
                // cria um leitor de informaÃ§Ãµes (com o nome reader)
                MySqlDataReader reader = comando.ExecuteReader();
                // Limpa ListView
                lstContatos.Items.Clear();
                // While percorre todos os resultados que forem encontrados no BD
                while (reader.Read())
                //reader Ã© o leitor das informaÃ§Ãµes criado acima; MÃ©todo Read lÃª prÃ³xima linha do BD
                //Quando nÃ£o houver mais linhas para ler, while retorna como False
                {
                    // Cria um vetor para acomodar os campos (Colunas) da tabela
                    string[] linha =
                    {
                        reader.GetString(0),
                        reader.GetString(1),
                        reader.GetString(2),
                        reader.GetString(3),
                    };
                    // Monta a linha que serÃ¡ exibida no ListView com os elementos do vetor linha
                    var linha_listview = new ListViewItem(linha);
                    lstContatos.Items.Add(linha_listview);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                Conexao.Close();
            }
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTelefone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtTelefone_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        // EVENTO SELEÃ‡ÃƒO DE LINHA COM BOTÃƒO DIREITO DO MOUSE
        private void lstContatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListView.SelectedListViewItemCollection item_Selecionado = lstContatos.SelectedItems;

            foreach (ListViewItem item in item_Selecionado)
            {
                id_Contato_Sel = Convert.ToInt32(item.SubItems[0].Text);

                txtNome.Text = item.SubItems[1].Text;
                txtEmail.Text = item.SubItems[2].Text;
                mtxtTelefone.Text = item.SubItems[3].Text;

                btnExcluir.Visible = true;
            }

        }

        // EVENTO EXCLUSÃƒO DE LINHA DO BANCO DE DADOS
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            excluirContato();
            btnExcluir.Visible = false;
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            excluirContato();
        }

        // MÃ‰TODO PARA EXCLUSÃƒO DE LINHA DO BANCO DE DADOS
        private void excluirContato()
        {
            try
            {

                // Criar conexÃ£o
                Conexao = new MySqlConnection(data_source);
                Conexao.Open();
                MySqlCommand cmd = new MySqlCommand();

                cmd.Connection = Conexao;

                DialogResult conf = MessageBox.Show("Confirma exclusÃ£o do registro?",
                                                    "ExclusÃ£o de registro",
                                                    MessageBoxButtons.YesNo,
                                                    MessageBoxIcon.Warning);

                if (conf == DialogResult.Yes)
                {
                    cmd.CommandText = "DELETE FROM contatos WHERE id=@id";

                    //cmd.Prepare();
                    cmd.Parameters.AddWithValue("@id", id_Contato_Sel);

                    cmd.ExecuteNonQuery();

                    // Excluir linha no banco de dados
                    MessageBox.Show("Contato ExcluÃ­do com Sucesso! ", " ",
                                        MessageBoxButtons.OK,
                                        MessageBoxIcon.Information);

                    limparCampos();

                    btnExcluir.Visible = false;

                    carregarContatos();
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro " + ex.Number + " Ocorreu: " + ex.Message,
                                "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu: " + ex.Message,
                                " Erro", MessageBoxButtons.OK,
                                         MessageBoxIcon.Error);
            }
            finally
            {
                Conexao.Close();
            }
        }

        // LIMPA CAMPOS DO FORMULÃRIO
        private void limparCampos()
        {
            // Limpa campos do formulÃ¡rio
            id_Contato_Sel = null;
            txtNome.Text = "";
            mtxtTelefone.Text = "";
            txtEmail.Text = "";
        }

        
    }
}